//
//  HUD.swift
//
//  Created by Spike on 2019/10/22.
//

import Foundation
import UIKit

@_exported import MBProgressHUD
import Lottie

enum HUD {
    @discardableResult
    static func showLoading(in view: UIView, hasBackground: Bool = false) -> MBProgressHUD {
        let hud = MBProgressHUD(for: view) ?? MBProgressHUD(view: view)

        let animationView = AnimationView(name: hasBackground ? "loading_with_background" : "loading")
        animationView.loopMode = .loop
        hud.mode = .customView
        hud.customView = animationView
        hud.bezelView.style = .solidColor
        hud.bezelView.color = .clear
        hud.removeFromSuperViewOnHide = true
        view.addSubview(hud)
        animationView.play()
        hud.show(animated: true)

        return hud
    }

    static func hide(in view: UIView, animated: Bool = true) {
        if let hud = MBProgressHUD(for: view) {
            hud.hide(animated: animated)
        }
    }

    /// If delay <= 0, won't auto hide
    @discardableResult
    static func showMessage(_ text: String, in view: UIView, hideAfter delay: TimeInterval = 3) -> MBProgressHUD {
        let hud = MBProgressHUD(for: view) ?? MBProgressHUD(view: view)
        hud.isUserInteractionEnabled = false
        hud.margin = 20
        hud.mode = .text
        hud.label.font = UIFont.systemFont(ofSize: 14)
        hud.bezelView.style = .solidColor
        hud.bezelView.color = UIColor(white: 0, alpha: 0.8)
        hud.bezelView.layer.cornerRadius = 6
        hud.label.textColor = .white
        hud.label.numberOfLines = 0
        hud.label.text = text
        hud.removeFromSuperViewOnHide = true
        view.addSubview(hud)
        hud.show(animated: true)

        if delay > 0.01 {
            hud.hide(animated: true, afterDelay: delay)
        }

        return hud
    }

    static func showMessage(_ text: String, hideAfter delay: TimeInterval = 3) {
        guard let view = UIApplication.shared.keyWindow?.rootViewController?.view else { return }
        showMessage(text, in: view, hideAfter: delay)
    }
}
