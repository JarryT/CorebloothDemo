//
//  PeripheralManager.swift
//  BluetoothPeripheral
//
//  Created by 汤军 on 2019/11/22.
//  Copyright © 2019 JarryTang. All rights reserved.
//

import UIKit
import CoreBluetooth

protocol PeripheralManagerDelegate: NSObjectProtocol {
    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager)
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest)
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest])
}

class PeripheralManager: NSObject {

    //static let instance = PeripheralManager()

    private var manager: CBPeripheralManager!

    private var myServices = [CBMutableService]()

    //private var myCharacteristics = [CBMutableCharacteristic]()

    weak var delegate: PeripheralManagerDelegate?

    var advertisingName: String?

    var serviceUUIDs: [CBUUID] {
        let uuids = myServices.flatMap({ [$0.uuid] })
        return uuids
    }

    private var readingCharacteristic: CBMutableCharacteristic?

    private var writingCharacteristic: CBMutableCharacteristic?


    var state: CBManagerState {
        return manager.state
    }

    override init() {
        super.init()
        manager = CBPeripheralManager(delegate: self, queue: nil, options: nil)
    }

    /// add a service with associated characteristics, once you pass characteristics here, they will be added to the service automatically
    /// - Parameter service: the service to be broadcasted and will be received by central
    /// - Parameter characteristic: characteristics attched to service
    func add(service: CBMutableService, characteristics: [CBMutableCharacteristic]) {
        service.characteristics = characteristics
        myServices.append(service)
        manager.add(service)
    }

    ///peripheral start advertise broadcast when return true
    ///if return value is false, need to chack state properity to see why
    func startAdvertising() -> Bool {
        if manager.state == .poweredOn {
            var info = [String : Any]()
            info[CBAdvertisementDataServiceUUIDsKey] = serviceUUIDs
            if let name = advertisingName {
                info[CBAdvertisementDataLocalNameKey] = name
            }
            manager.startAdvertising(info)
            return true
        } else {
            return false
        }
    }

    ///start advertise broadcast
    func stopAdvertising() {
        manager.stopAdvertising()
    }

    ///remove cached data when instance is no longer used
    func clear() {        
        myServices.removeAll()
    }
}

extension PeripheralManager: CBPeripheralManagerDelegate {

    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {        
        delegate?.peripheralManagerDidUpdateState(peripheral)
    }
    func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
        print("didAdd service")
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
        print("didReceiveRead")
        delegate?.peripheralManager(peripheral, didReceiveRead: request)
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        print("didReceiveRead")
        delegate?.peripheralManager(peripheral, didReceiveWrite: requests)
    }
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
        print("didSubscribeTo characteristic")
    }
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
        print("didUnsubscribeFrom characteristic")
    }
    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        print("didStartAdvertising")
    }
    func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) {
        print("peripheralManagerIsReady")
    }
    @available(iOS 11.0, *)
    func peripheralManager(_ peripheral: CBPeripheralManager, didOpen channel: CBL2CAPChannel?, error: Error?) {
        print("didOpen channel")
    }
    func peripheralManager(_ peripheral: CBPeripheralManager, didPublishL2CAPChannel PSM: CBL2CAPPSM, error: Error?) {
        print("didPublishL2CAPChannel")
    }
    func peripheralManager(_ peripheral: CBPeripheralManager, didUnpublishL2CAPChannel PSM: CBL2CAPPSM, error: Error?) {
        print("didUnpublishL2CAPChannel")
    }
}

