//
//  CentralViewController.swift
//  Bluetooth
//
//  Created by 汤军 on 2019/11/20.
//  Copyright © 2019 JarryTang. All rights reserved.
//

import UIKit
import CoreBluetooth
import MJRefresh

let myCharacteristicUUID = CBUUID(string: "477A2967-1FAB-4DC5-920A-DEE5DE685A3D")
let myServiceUUID = CBUUID(string: "6E6B5C64-FAF7-40AE-9C21-D4933AF45B23")

enum DataType {
    case text
}

class CentralViewController: UIViewController {

    let centralManager = CentralManager()

    var peripherals = [CBPeripheral]()

    let textData = "Structs are preferable if they are relatively small and copiable because copying is way safer than having multiple references to the same instance as happens with classes. This is especially important when passing around a variable to many classes and/or in a multithreaded environment. If you can always send a copy of your variable to other places, you never have to worry about that other place changing the value of your variable underneath you.With Structs, there is much less need to worry about memory leaks or multiple threads racing to access/modify a single instance of a variable. (For the more technically minded, the exception to that is when capturing a struct inside a closure because then it is actually capturing a reference to the instance unless you explicitly mark it to be copied).Classes can also become bloated because a class can only inherit from a single superclass. That encourages us to create huge superclasses that encompass many different abilities that are only loosely related. Using protocols, especially with protocol extensions where you can provide implementations to protocols, allows you to eliminate the need for classes to achieve this sort of behavior.".data(using: .utf8)

    lazy var tableView: UITableView = {
        let view = UITableView()
        view.rowHeight = 44
        return view
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        view.backgroundColor = .white

        centralManager.delegate = self
        centralManager.isConnectStateChanged = { peripheral, isConnected in
            self.connectStateChanged(peripheral: peripheral, isConnected: isConnected)
        }
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.frame = view.bounds
        tableView.mj_header = MJRefreshNormalHeader.init(refreshingBlock: {
            self.headerRefresh()
        })
    }

    func headerRefresh() {
        if centralManager.state == .poweredOn {
            peripherals.removeAll()
            tableView.reloadData()
            _ = centralManager.startScanning(serviceId: [myServiceUUID])
        }
        tableView.mj_header.endRefreshing()
    }

    func connectStateChanged(peripheral: CBPeripheral, isConnected: Bool) {
        if let index = peripherals.firstIndex(of: peripheral) {
            if let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) {
                cell.isSelected = isConnected
            }
        }
    }
}

extension CentralViewController: CentralManagerDelegate {
    func centralManagerDidUpdateState(_ manager: CentralManager) {
        if manager.state == .poweredOn {
            _ = manager.startScanning(serviceId: [myServiceUUID])
        }
    }

    /// advertisementData:  kCBAdvDataIsConnectable: Bool, kCBAdvDataServiceUUIDs: CBUUID, kCBAdvDataLocalName: Jarry's peripheral
    func centralManager(_ manager: CentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        if peripheral.name == nil || (peripheral.name)!.count == 0 {
            return
        }
        if peripherals.contains(where: { $0.identifier == peripheral.identifier}) {
            print("already exist .... \(peripheral.identifier) ")
            return
        }
        peripherals.append(peripheral)
        tableView.insertRows(at: [IndexPath(row: peripherals.count - 1, section: 0)], with: .fade)
    }

    func centralManager(_ manager: CentralManager, didConnect peripheral: CBPeripheral) {

    }

    func centralManager(_ manager: CentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {

    }

    func centralManager(_ manager: CentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {

    }

    func centralManager(_ central: CentralManager, peripheral: CBPeripheral, updateWritedCount count: Int) {
        let ratioValue = (Float(count) / Float(textData!.count)) * 100
        let formatValue = String(format:"%.2f", arguments: [ratioValue])
        let ratio = "\(formatValue)/100"
        if ratioValue < 100 {
            title = "Sending: \(ratio)"
        } else {
            title = "Send finished"
            HUD.showMessage("finish", hideAfter: 1)
        }
        print(ratio)
    }

    func centralManager(_ central: CentralManager, peripheral: CBPeripheral, finishWrite error: Error?) {
        if let error = error  {
            HUD.showMessage(error.localizedDescription, hideAfter: 3)
            return
        }
        title = "Send finished"
        HUD.showMessage("finish", hideAfter: 1)
    }
}

extension CentralViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return peripherals.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: CentralCell!
        cell = tableView.dequeueReusableCell(withIdentifier: CentralCell.description()) as? CentralCell
        if cell == nil {
            cell = CentralCell(style: .subtitle, reuseIdentifier: UITableViewCell.description())
            cell.selectionStyle = .none
        }
        let peripheral = peripherals[indexPath.row]
        cell.textLabel?.text = peripheral.name
        cell.detailTextLabel?.text = peripheral.identifier.description
        if let connectedPeripheral = centralManager.connectedPeripheral {
            cell.isSelected = connectedPeripheral.identifier == peripheral.identifier
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        let peripheral = peripherals[indexPath.row]

        if peripheral.state == .connected {
            print("alreay connected .... ")
            let service = peripheral.services?.first
            if let character = service?.characteristics?.first {
                centralManager.send(data: textData!, to: character)
            }
            return
        }

        centralManager.connectTo(peripheral: peripheral)
    }
}
