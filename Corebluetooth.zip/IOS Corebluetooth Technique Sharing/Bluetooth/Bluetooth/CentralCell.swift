//
//  PeripheralCell.swift
//  BluetoothPeripheral
//
//  Created by 汤军 on 2019/11/26.
//  Copyright © 2019 JarryTang. All rights reserved.
//

import UIKit

class CentralCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        if selected {
            accessoryView = UIImageView.init(image: UIImage(named: "signup_location_sel"))
        } else {
            accessoryView = nil
        }
    }

}
