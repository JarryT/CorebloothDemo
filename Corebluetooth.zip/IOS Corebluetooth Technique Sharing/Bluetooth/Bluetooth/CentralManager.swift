//
//  CentralManager.swift
//  Bluetooth
//
//  Created by 汤军 on 2019/11/22.
//  Copyright © 2019 JarryTang. All rights reserved.
//

import UIKit
import CoreBluetooth

protocol CentralManagerDelegate: NSObjectProtocol {
    func centralManagerDidUpdateState(_ manager: CentralManager)
    func centralManager(_ manager: CentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber)
    func centralManager(_ manager: CentralManager, didConnect peripheral: CBPeripheral)
    func centralManager(_ manager: CentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?)
    func centralManager(_ manager: CentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?)

    /// return the sended data count in a real time
    func centralManager(_ central: CentralManager, peripheral: CBPeripheral, updateWritedCount count: Int)

    /// finish a write operate, maybe failed if an error occurs
    func centralManager(_ central: CentralManager, peripheral: CBPeripheral, finishWrite error: Error?)
}

class CentralManager: NSObject {

    private var manager: CBCentralManager!

    weak var delegate: CentralManagerDelegate?

    var isConnetced: Bool = false

    var isConnectStateChanged: ((_ peripheral: CBPeripheral, _ isConnected: Bool) -> Void)?

    var connectedPeripheral: CBPeripheral? {
        return _connectedPeripheral
    }

    var state: CBManagerState {
        return manager.state
    }

    private var servieUUIDS: [CBUUID] = [CBUUID]()
    private var characteristicUUIDS: [CBUUID] = [CBUUID]()

    private var writeData: Data?
    private let writeDataCount: Int = 20
    private var writeDataOffSet = 0
    private var totalWriteCount = 0
    private var shouldStopFlag = true


    private var _connectedPeripheral: CBPeripheral?
    private var operateCharacteristic: CBCharacteristic?

    override init() {
        super.init()
        manager = CBCentralManager.init(delegate: self, queue: DispatchQueue.main)
    }
}

extension CentralManager {

    /// start scan for a sort of specific service
    /// - Parameter serviceId: sevice UUIDs
    func startScanning(serviceId: [CBUUID]?) -> Bool {
        if state == .poweredOn {
            manager.scanForPeripherals(withServices: serviceId, options: nil)
            return true
        } else {
            return false
        }
    }

    func stopScanning() {
        manager.stopScan()
    }

    func connectTo(peripheral: CBPeripheral) {
        manager.connect(peripheral, options: nil)
        stopScanning()
    }

    func disconnect(peripheral: CBPeripheral) {
        manager.cancelPeripheralConnection(peripheral)
    }

    func send(data: Data, to characteristic: CBCharacteristic) {
        if data.count == 0 { return }
        operateCharacteristic = characteristic
        writeData = data
        totalWriteCount = data.count
        writeDataOffSet = 0
        updateWriteDataState(at: 0)
    }

    private func updateWriteDataState(at offSet: Int) {
        if let data = dataToWrite(), let characteristic = operateCharacteristic, data.count > 0 {
            _connectedPeripheral?.writeValue(data, for: characteristic, type: .withResponse)
        }
    }

    private func dataToWrite() -> Data? {
        print("writeDataOffSet -- \(writeDataOffSet)")
        if let rawData = writeData {
            let totalCount = rawData.count
            if totalCount > writeDataCount {
                let remainCount = totalCount - writeDataOffSet
                let rangeCount = remainCount > writeDataCount ? writeDataCount : remainCount
                if let range = Range(NSRange.init(location: writeDataOffSet, length: rangeCount)) {
                    return rawData.subdata(in: range)
                }
            } else if totalCount > 0 {
                return rawData
            }
        }
        return nil
    }
}

extension CentralManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("didWriteValueFor characteristic error: \(error)")
        } else {

            if writeDataOffSet < totalWriteCount {
                if let data = dataToWrite(), data.count > 0 {
                    writeDataOffSet += data.count
                    updateWriteDataState(at: writeDataOffSet)
                }
                print("didWriteValueFor sending -- \(writeDataOffSet)")
                delegate?.centralManager(self, peripheral: peripheral, updateWritedCount: writeDataOffSet)
            } else {
                print("didWriteValueFor sended -- \(totalWriteCount)")
                delegate?.centralManager(self, peripheral: peripheral, finishWrite: nil)
                return
            }
        }
    }

    func peripheralDidUpdateName(_ peripheral: CBPeripheral) {
        print("peripheralDidUpdateName")
    }

    func peripheral(_ peripheral: CBPeripheral, didModifyServices invalidatedServices: [CBService]) {
        print("didModifyServices")
    }
    func peripheral(_ peripheral: CBPeripheral, didReadRSSI RSSI: NSNumber, error: Error?) {
        print("didReadRSSI")
    }

    /// discover the specific services
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        print("didDiscoverServices")
        if let services = peripheral.services {
            for service in services {
                peripheral.discoverCharacteristics(nil, for: service)
            }
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverIncludedServicesFor service: CBService, error: Error?) {
        print("didDiscoverIncludedServicesFor")
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        print("didDiscoverCharacteristicsFor")
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        print("didUpdateValueFor ")
        if let error = error {
            print(error)
        }
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        print("didUpdateNotificationStateFor characteristic")
    }
    func peripheral(_ peripheral: CBPeripheral, didDiscoverDescriptorsFor characteristic: CBCharacteristic, error: Error?) {
        print("didDiscoverDescriptorsFor characteristic")
    }
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor descriptor: CBDescriptor, error: Error?) {
        print("didUpdateValueFor descriptor")
    }
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor descriptor: CBDescriptor, error: Error?) {
        print("didWriteValueFor descriptor")
    }
    func peripheralIsReady(toSendWriteWithoutResponse peripheral: CBPeripheral) {
        print("toSendWriteWithoutResponse")
    }

    @available(iOS 11.0, *)
    func peripheral(_ peripheral: CBPeripheral, didOpen channel: CBL2CAPChannel?, error: Error?) {
        print("did Open channel")
    }
}

extension CentralManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        print("centralManager Did UpdateState")
        delegate?.centralManagerDidUpdateState(self)
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        print("did Discover peripheral")
        delegate?.centralManager(self, didDiscover: peripheral, advertisementData: advertisementData, rssi: RSSI)
    }
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("did Connect peripheral")
        if let peripheral = _connectedPeripheral {
            isConnectStateChanged?(peripheral, true)
        }
        isConnetced = true
        _connectedPeripheral = peripheral
        delegate?.centralManager(self, didConnect: peripheral)
        peripheral.delegate = self
        peripheral.discoverServices([myServiceUUID])
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("did DisconnectPeripheral \(error)")
        if let peripheral = _connectedPeripheral {
            isConnectStateChanged?(peripheral, false)
        }
        isConnetced = false
        _connectedPeripheral = nil
        delegate?.centralManager(self, didDisconnectPeripheral: peripheral, error: error)
    }
    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("didFailToConnect peripheral -- \(String(describing: error))")
        delegate?.centralManager(self, didFailToConnect: peripheral, error: error)
    }
}
