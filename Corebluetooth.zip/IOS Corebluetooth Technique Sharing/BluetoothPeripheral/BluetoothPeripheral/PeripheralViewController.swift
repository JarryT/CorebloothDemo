//
//  PeripheralViewController.swift
//  Bluetooth
//
//  Created by 汤军 on 2019/11/20.
//  Copyright © 2019 JarryTang. All rights reserved.
//

import UIKit
import CoreBluetooth

let myCharacteristicUUID = CBUUID(string: "477A2967-1FAB-4DC5-920A-DEE5DE685A3D")
let myServiceUUID = CBUUID(string: "6E6B5C64-FAF7-40AE-9C21-D4933AF45B23")

class PeripheralViewController: UIViewController {

    var tempData: Data?

    var peripheralManager = PeripheralManager()

    lazy var textLabel: UITextView = {
        let view = UITextView()
        view.isEditable = false
        view.backgroundColor = UIColor.lightGray
        return view
    }()

    lazy var myService: CBMutableService = {
        return CBMutableService(type: myServiceUUID, primary: true)
    }()

    //如果给 characteristic 设置了 value 参数，那么这个 value 会被缓存，并且 properties 和 permissions 会自动设置为可读。如果想要 characteristic 可写，或者在其生命周期会改变它的值，那需要将 value 设置为 nil。这样的话，就会动态的来处理 value 。
    lazy var myCharacteristic: CBMutableCharacteristic = {
        let properties = CBCharacteristicProperties.init(arrayLiteral: .read, .write)
        let permissions = CBAttributePermissions.init(arrayLiteral: .readable, .writeable)
        let defaultValue = "Text"
        //传入Value后、properties和permissions只能是可读、否则会crash
        let value = defaultValue.data(using: .utf8)
        return CBMutableCharacteristic(type: myCharacteristicUUID, properties: properties, value: nil, permissions: permissions)
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        view.addSubview(textLabel)
        textLabel.frame = CGRect(x: 20, y: 84, width: view.frame.width - 40, height: 200)

        peripheralManager.delegate = self
    }
}

extension PeripheralViewController: PeripheralManagerDelegate {

    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        if peripheral.state == .poweredOn {
            peripheralManager.advertisingName = "Jarry's peripheral"
            peripheralManager.add(service: myService, characteristics: [myCharacteristic])
            _ = peripheralManager.startAdvertising()
        }
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
            print("didReceiveRead")
            if request.characteristic.uuid.isEqual(myCharacteristicUUID) {
                if let value = myCharacteristic.value {
                    //校验
                    if (request.offset > value.count) {
                        peripheral.respond(to: request, withResult: .invalidOffset)
                        return;
                    }
                    if let range = Range(NSMakeRange(request.offset, value.count - request.offset)) {
                        //传递数据
                        request.value = value.subdata(in: range)
                        //回调
                        peripheral.respond(to: request, withResult: .success)
                    }
                } else {
                    peripheral.respond(to: request, withResult: .attributeNotFound)
                }
            }
        }

        func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
            for request in requests {
                //验证、校验UUID 和 offset
                if request.characteristic.uuid.uuidString == myCharacteristicUUID.uuidString {
                    if let data = request.value {
                        print("count: \(data.count)")
                        if tempData == nil {
                            tempData = data
                        } else {
                            tempData?.append(data)
                        }
                        if let allData = tempData, let value = String(data: allData, encoding: .utf8) {
                            textLabel.text = value
                        }
                        peripheral.respond(to: request, withResult: .success)
                    }
                }
            }
        }
}
